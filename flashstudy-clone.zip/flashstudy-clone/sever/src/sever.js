require('dotenv').config();
const express = require('express');
const helmet = require('helmet');
const cors = require('cors');
const rateLimit = require('express-rate-limit');
const connectDB = require('./config/db');

const authRoutes = require('./routes/auth');
const courseRoutes = require('./routes/courses');
const lessonRoutes = require('./routes/lessons');
const quizRoutes = require('./routes/quizzes');
const adminRoutes = require('./routes/admin');

const app = express();

app.use(helmet());
app.use(cors({ origin: process.env.FRONTEND_URL || '*' }));
app.use(express.json({ limit: '10mb' }));

const limiter = rateLimit({ windowMs: 15*60*1000, max: 300 });
app.use(limiter);

app.use('/api/auth', authRoutes);
app.use('/api/courses', courseRoutes);
app.use('/api/lessons', lessonRoutes);
app.use('/api/quizzes', quizRoutes);
app.use('/api/admin', adminRoutes);

app.get('/', (req, res) => res.send('FlashStudy Clone API'));

const PORT = process.env.PORT || 4000;
connectDB(process.env.MONGODB_URI || 'mongodb://localhost:27017/flashstudy')
  .then(() => app.listen(PORT, () => console.log(`Server listening ${PORT}`)))
  .catch(err => console.error(err));
