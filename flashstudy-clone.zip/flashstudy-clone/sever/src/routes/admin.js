const express = require('express');
const User = require('../models/User');
const requireAuth = require('../middlewares/auth');
const requireRole = require('../middlewares/roles');
const router = express.Router();

router.get('/users', requireAuth, requireRole('admin'), async (req, res) => {
  const users = await User.find().select('-passwordHash');
  res.json(users);
});

module.exports = router;
