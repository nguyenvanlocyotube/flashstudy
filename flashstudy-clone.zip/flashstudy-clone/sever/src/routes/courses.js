const express = require('express');
const slugify = require('slugify');
const Course = require('../models/Course');
const Lesson = require('../models/Lesson');
const requireAuth = require('../middlewares/auth');
const requireRole = require('../middlewares/roles');
const router = express.Router();

// list courses (with query)
router.get('/', async (req, res) => {
  const { q, page = 1, limit = 10 } = req.query;
  const filter = {};
  if (q) filter.$or = [{ title: new RegExp(q, 'i') }, { shortDescription: new RegExp(q, 'i') }];
  const courses = await Course.find(filter).skip((page-1)*limit).limit(parseInt(limit));
  res.json(courses);
});

// get detail
router.get('/:id', async (req, res) => {
  const course = await Course.findById(req.params.id).populate({ path: 'lessons', options: { sort: { order: 1 } } });
  if (!course) return res.status(404).json({ message: 'Not found' });
  res.json(course);
});

// admin create
router.post('/', requireAuth, requireRole('admin'), async (req, res) => {
  const { title, shortDescription, description, categories, level, price } = req.body;
  const course = new Course({
    title,
    slug: slugify(title, { lower: true }),
    shortDescription,
    description,
    categories,
    level,
    price
  });
  await course.save();
  res.status(201).json(course);
});

// admin add lesson
router.post('/:id/lessons', requireAuth, requireRole('admin'), async (req, res) => {
  const course = await Course.findById(req.params.id);
  if (!course) return res.status(404).json({ message: 'Course not found' });
  const { title, videoUrl, content, order } = req.body;
  const lesson = new Lesson({ title, videoUrl, content, order, course: course._id });
  await lesson.save();
  course.lessons.push(lesson._id);
  await course.save();
  res.status(201).json(lesson);
});

module.exports = router;
