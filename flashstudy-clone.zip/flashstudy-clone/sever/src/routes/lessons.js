const express = require('express');
const Lesson = require('../models/Lesson');
const requireAuth = require('../middlewares/auth');
const router = express.Router();

router.get('/:id', async (req, res) => {
  const lesson = await Lesson.findById(req.params.id);
  if (!lesson) return res.status(404).json({ message: 'Not found' });
  res.json(lesson);
});

module.exports = router;
