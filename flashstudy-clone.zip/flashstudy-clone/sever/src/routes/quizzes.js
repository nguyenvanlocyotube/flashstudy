const express = require('express');
const Quiz = require('../models/Quiz');
const router = express.Router();

router.get('/:id', async (req, res) => {
  const quiz = await Quiz.findById(req.params.id);
  if (!quiz) return res.status(404).json({ message: 'Not found' });
  // don't send isCorrect back to client
  const publicQuestions = quiz.questions.map(q => ({
    question: q.question,
    options: q.options.map(o => ({ text: o.text }))
  }));
  res.json({ id: quiz._id, title: quiz.title, questions: publicQuestions });
});

// submit quiz: client sends answers array of chosen option indices
router.post('/:id/submit', async (req, res) => {
  const { answers } = req.body; // [0,2,1]
  const quiz = await Quiz.findById(req.params.id);
  if (!quiz) return res.status(404).json({ message: 'Not found' });
  let score = 0;
  quiz.questions.forEach((q, i) => {
    const chosenIndex = answers[i];
    if (q.options[chosenIndex] && q.options[chosenIndex].isCorrect) score++;
  });
  res.json({ total: quiz.questions.length, score });
});

module.exports = router;
