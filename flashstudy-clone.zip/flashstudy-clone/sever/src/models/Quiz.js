const mongoose = require('mongoose');

const QuizSchema = new mongoose.Schema({
  title: String,
  course: { type: mongoose.Schema.Types.ObjectId, ref: 'Course' },
  questions: [{
    question: String,
    options: [{ text: String, isCorrect: Boolean }]
  }]
});

module.exports = mongoose.model('Quiz', QuizSchema);
