require('dotenv').config();
const mongoose = require('mongoose');
const bcrypt = require('bcrypt');
const User = require('../models/User');
const Course = require('../models/Course');
const Lesson = require('../models/Lesson');
const Quiz = require('../models/Quiz');

(async function seed() {
  try {
    await mongoose.connect(process.env.MONGODB_URI || 'mongodb://localhost:27017/flashstudy');
    await User.deleteMany({});
    await Course.deleteMany({});
    await Lesson.deleteMany({});
    await Quiz.deleteMany({});

    const pass = await bcrypt.hash('admin123', 10);
    const admin = await User.create({ name: 'Admin', email: 'admin@flashclone.test', passwordHash: pass, role: 'admin' });

    const course = await Course.create({
      title: 'Lập trình Web cơ bản',
      slug: 'lap-trinh-web-co-ban',
      shortDescription: 'Học HTML, CSS, JavaScript cơ bản.',
      description: '<p>Khóa học cho người mới bắt đầu.</p>',
      instructor: admin._id,
      categories: ['Lập trình', 'Web'],
      level: 'Basic'
    });

    const l1 = await Lesson.create({ title: 'Giới thiệu HTML', course: course._id, order: 1, videoUrl: 'https://www.w3schools.com/html/mov_bbb.mp4', content: '<p>Nội dung bài 1</p>' });
    const l2 = await Lesson.create({ title: 'CSS cơ bản', course: course._id, order: 2, videoUrl: 'https://www.w3schools.com/html/mov_bbb.mp4', content: '<p>Nội dung bài 2</p>' });

    course.lessons.push(l1._id, l2._id);
    await course.save();

    const quiz = await Quiz.create({
      title: 'Quiz cơ bản',
      course: course._id,
      questions: [
        { question: 'HTML là viết tắt của?', options: [{ text: 'Hyper Text Markup Language', isCorrect: true }, { text: 'Home Tool Markup', isCorrect: false }] }
      ]
    });

    console.log('Seed completed. Admin:', admin.email, 'Password: admin123');
    process.exit(0);
  } catch (e) {
    console.error(e);
    process.exit(1);
  }
})();
