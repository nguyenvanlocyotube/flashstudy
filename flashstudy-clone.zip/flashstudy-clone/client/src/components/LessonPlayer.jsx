import React, { useState } from 'react';

export default function LessonPlayer({ lessons = [] }) {
  const [idx, setIdx] = useState(0);
  const lesson = lessons[idx];
  if (!lesson) return <div>Không có bài học</div>;
  return (
    <div>
      <h3 className="text-xl font-semibold mb-2">{lesson.title}</h3>
      <div className="bg-black">
        <video controls src={lesson.videoUrl} style={{ width: '100%' }} />
      </div>
      <div className="mt-4" dangerouslySetInnerHTML={{ __html: lesson.content || '' }} />
      <div className="flex justify-between mt-4">
        <button onClick={() => setIdx(Math.max(0, idx-1))} className="px-3 py-1 bg-gray-200 rounded">Trước</button>
        <button onClick={() => setIdx(Math.min(lessons.length-1, idx+1))} className="px-3 py-1 bg-blue-600 text-white rounded">Tiếp</button>
      </div>
    </div>
  );
}
