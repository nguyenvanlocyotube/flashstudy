import React from 'react';
import { Link } from 'react-router-dom';

export default function CourseCard({ course }) {
  return (
    <div className="bg-white p-4 rounded shadow">
      <img src={course.coverImage || 'https://via.placeholder.com/400x200'} alt="" className="w-full h-40 object-cover rounded" />
      <h3 className="text-lg font-semibold mt-2">{course.title}</h3>
      <p className="text-sm">{course.shortDescription}</p>
      <Link to={`/courses/${course._id}`} className="text-blue-600 mt-2 inline-block">Chi tiết</Link>
    </div>
  );
}
