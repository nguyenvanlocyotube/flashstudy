import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import api from '../services/api';

export default function Header({ user, setUser }) {
  const nav = useNavigate();
  const logout = () => {
    localStorage.removeItem('token');
    setUser(null);
    api.defaults.headers.common['Authorization'] = '';
    nav('/');
  };
  return (
    <header className="bg-white shadow">
      <div className="container mx-auto flex items-center justify-between p-4">
        <div className="text-xl font-bold"><Link to="/">FlashStudy</Link></div>
        <nav className="space-x-4">
          <Link to="/courses">Khóa học</Link>
          <Link to="/blog">Blog</Link>
          {user ? (
            <>
              <Link to="/dashboard">Dashboard</Link>
              <button onClick={logout} className="ml-2">Đăng xuất</button>
            </>
          ) : (
            <>
              <Link to="/login">Đăng nhập</Link>
              <Link to="/signup" className="ml-2">Đăng ký</Link>
            </>
          )}
        </nav>
      </div>
    </header>
  );
}
