import React, { useState } from 'react';
import api, { setAuthToken } from '../services/api';
import { useNavigate } from 'react-router-dom';

export default function Login({ setUser }) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const nav = useNavigate();

  const submit = async (e) => {
    e.preventDefault();
    try {
      const r = await api.post('/auth/login', { email, password });
      localStorage.setItem('token', r.data.accessToken);
      setAuthToken(r.data.accessToken);
      setUser(r.data.user);
      nav('/dashboard');
    } catch (err) {
      alert('Đăng nhập thất bại');
    }
  };

  return (
    <form onSubmit={submit} className="max-w-md mx-auto bg-white p-6 rounded shadow">
      <h2 className="text-2xl mb-4">Đăng nhập</h2>
      <input className="w-full p-2 border mb-3" value={email} onChange={e => setEmail(e.target.value)} placeholder="Email" />
      <input type="password" className="w-full p-2 border mb-3" value={password} onChange={e => setPassword(e.target.value)} placeholder="Mật khẩu" />
      <button type="submit" className="bg-blue-600 text-white py-2 px-4 rounded">Đăng nhập</button>
    </form>
  );
}
