import React, { useEffect, useState } from 'react';
import api from '../services/api';
import CourseCard from '../components/CourseCard';

export default function Courses() {
  const [courses, setCourses] = useState([]);
  useEffect(() => {
    api.get('/courses').then(r => setCourses(r.data)).catch(console.error);
  }, []);
  return (
    <div>
      <h2 className="text-2xl mb-4">Danh sách khóa học</h2>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {courses.map(c => <CourseCard key={c._id} course={c} />)}
      </div>
    </div>
  );
}
