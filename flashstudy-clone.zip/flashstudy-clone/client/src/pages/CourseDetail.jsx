import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import api from '../services/api';
import LessonPlayer from '../components/LessonPlayer';

export default function CourseDetail() {
  const { id } = useParams();
  const [course, setCourse] = useState(null);

  useEffect(() => {
    api.get(`/courses/${id}`).then(r => setCourse(r.data)).catch(console.error);
  }, [id]);

  if (!course) return <div>Loading...</div>;
  return (
    <div className="grid md:grid-cols-3 gap-6">
      <div className="md:col-span-2">
        <LessonPlayer lessons={course.lessons} />
      </div>
      <aside className="bg-white p-4 rounded shadow">
        <h2 className="font-bold">{course.title}</h2>
        <p>{course.shortDescription}</p>
        <div className="mt-4">
          <h3>Danh sách bài</h3>
          <ol className="mt-2">
            {course.lessons.map(l => <li key={l._id}>{l.order}. {l.title}</li>)}
          </ol>
        </div>
      </aside>
    </div>
  );
}
