import React, { useState } from 'react';
import api from '../services/api';
import { useNavigate } from 'react-router-dom';

export default function Signup() {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const nav = useNavigate();

  const submit = async (e) => {
    e.preventDefault();
    try {
      await api.post('/auth/register', { name, email, password });
      alert('Đăng ký thành công. Đăng nhập để tiếp tục.');
      nav('/login');
    } catch (err) {
      alert('Lỗi đăng ký');
    }
  };

  return (
    <form onSubmit={submit} className="max-w-md mx-auto bg-white p-6 rounded shadow">
      <h2 className="text-2xl mb-4">Đăng ký</h2>
      <input className="w-full p-2 border mb-3" value={name} onChange={e => setName(e.target.value)} placeholder="Họ tên" />
      <input className="w-full p-2 border mb-3" value={email} onChange={e => setEmail(e.target.value)} placeholder="Email" />
      <input type="password" className="w-full p-2 border mb-3" value={password} onChange={e => setPassword(e.target.value)} placeholder="Mật khẩu" />
      <button type="submit" className="bg-green-600 text-white py-2 px-4 rounded">Đăng ký</button>
    </form>
  );
}
