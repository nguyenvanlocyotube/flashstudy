import React, { useEffect, useState } from 'react';
import api from '../services/api';
import { Link } from 'react-router-dom';

export default function Dashboard({ user }) {
  const [enrolledCourses, setEnrolled] = useState([]);
  useEffect(() => {
    if (!user) return;
    // naive: fetch courses list and filter (for demo)
    api.get('/courses').then(r => {
      setEnrolled(r.data);
    });
  }, [user]);

  if (!user) return <div>Vui lòng đăng nhập</div>;
  return (
    <div>
      <h2 className="text-2xl mb-4">Xin chào, {user.name}</h2>
      <h3 className="text-xl mb-2">Khóa học của bạn</h3>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {enrolledCourses.map(c => (
          <div key={c._id} className="bg-white p-4 rounded shadow">
            <h4 className="font-semibold">{c.title}</h4>
            <Link to={`/courses/${c._id}`} className="text-blue-600">Tiếp tục học</Link>
          </div>
        ))}
      </div>
    </div>
  );
}
